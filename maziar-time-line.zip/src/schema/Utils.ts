export type RouteItemType = { id: number, window: number[], steps: number[][] }
export type RouteListType = RouteItemType[]