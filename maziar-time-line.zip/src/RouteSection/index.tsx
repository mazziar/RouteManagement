import React from "react";
import { RouteList } from "./RouteList";


const Comp = () => {
    return <div className="w-100 p-5">
        <RouteList />
    </div>
}

export default Comp