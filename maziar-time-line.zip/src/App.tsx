import React from 'react';
import logo from './logo.svg';
import './App.css';

import RouteSection from './RouteSection'

export const App = () => {
  return (
    <RouteSection />
  );
}
